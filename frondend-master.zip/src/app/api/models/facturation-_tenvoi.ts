/* tslint:disable */

/**
 */
export class Facturation_Tenvoi {
    date?: string;
    timezone_type?: number;
    timezone?: string;
}
