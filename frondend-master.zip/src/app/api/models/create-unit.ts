/* tslint:disable */

/**
 */
export class CreateUnit {
    name?: string;
}
