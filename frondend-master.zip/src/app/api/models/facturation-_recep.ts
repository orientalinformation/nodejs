/* tslint:disable */
import { Facturation_Tenvoi } from './facturation-_tenvoi';

/**
 */
export class Facturation_recep {
    Trecep?: Facturation_Tenvoi;
    Nrecep?: number;
    Temps?: number;
}
