/* tslint:disable */

/**
 */
export class CreateAccessControl {
    role_id?: number;
    resource_id?: number;
}
