/* tslint:disable */

/**
 */
export class Group {
    _id?: number;
    id_company?: number;
    group_name?: string;
}
