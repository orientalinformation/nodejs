/* tslint:disable */

/**
 */
export class UpdateStorage {
    rent_area_ml?: number;
    id?: number;
    name?: string;
    area?: number;
    rent_area?: number;
    area_ml?: number;
    company_id?: number;
    max_radius?: number;
    lat?: number;
    lng?: number;
    city_code?: string;
    city_name?: string;
}
