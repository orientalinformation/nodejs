/* tslint:disable */

/**
 */
export class Role {
    _id?: number;
    role_name?: string;
}
