/* tslint:disable */
import { Product } from './product';

/**
 */
export class Storage_properties {
    nb_disp?: number;
    id?: number;
    value_2?: string;
    value_3?: string;
    area?: number;
    area_ml?: number;
    rent_area?: number;
    rent_area_ml?: number;
    value_1?: string;
    nb_loue?: number;
    total_m2?: number;
    total_ml?: number;
    nb_total?: number;
    taux?: number;
    product_id?: number[];
    product_match?: Product[];
}
