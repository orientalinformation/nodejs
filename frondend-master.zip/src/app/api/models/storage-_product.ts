/* tslint:disable */
import { Storage_properties } from './storage-_properties';

/**
 */
export class Storage_product {
    name?: string;
    alerts?: number[];
    properties?: Storage_properties[];
}
