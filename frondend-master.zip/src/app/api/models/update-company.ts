/* tslint:disable */

/**
 */
export class UpdateCompany {
    id?: number;
    name?: string;
    phone_number?: string;
    email?: string;
    address?: string;
    tax_number?: number;
    lat?: number;
    lng?: number;
    ref_name?: string;
}
