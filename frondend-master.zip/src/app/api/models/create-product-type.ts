/* tslint:disable */

/**
 */
export class CreateProductType {
    parent_id?: number;
    name?: string;
    unit_1?: number;
    unit_2?: number;
    unit_3?: number;
    value_1?: string;
    value_2?: string;
    value_3?: string;
}
