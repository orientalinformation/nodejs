/* tslint:disable */
import { User } from './user';

/**
 */
export class ViewLogin {
    // token?: string;
    user?: User;
}
