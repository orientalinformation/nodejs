/* tslint:disable */

/**
 */
export class DeviceData {
    id?: number;
    device_id?: number;
    data_receive?: string;
    created_at?: string;
}
