/* tslint:disable */

/**
 */
export class CreateSite {
    company_id?: number;
    name?: string;
    address?: string;
    lat?: number;
    lng?: number;
    area?: number;
    area_ml?: number;
    max_radius?: number;
    city_code?: string;
    city_name?: string;
}
