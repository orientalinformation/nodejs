/* tslint:disable */
import { Product } from './product';

/**
 */
export class Site_properties {
    n_product?: number;
    id?: number;
    value_2?: string;
    value_3?: string;
    m2?: number;
    ml?: number;
    nb_produit?: number;
    value_1?: string;
    jour?: number;
    chantier?: number;
    rent_min_max?: number;
    rent_min_today?: number;
    product_id?: number[];
    product_match?: Product[];
}
