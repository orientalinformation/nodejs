/* tslint:disable */

/**
 */
export class Accelerometer {
    date?: string;
    value?: {
        X?:number;
        Y?:number;
        Z?:number;
    };
}
