/* tslint:disable */

/**
 */
export class PayloadDeviceData {
    timestamp?: string;
    data?: string;
}
