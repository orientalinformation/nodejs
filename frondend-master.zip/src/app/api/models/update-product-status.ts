/* tslint:disable */

/**
 */
export class UpdateProductStatus {
    id?: number;
    name?: string;
    description?: string;
}
