/* tslint:disable */

/**
 */
export class Device {
    dev_eui?: string;
    id?: number;
    rfid?: string;
    lat?: number;
    lng?: number;
    description?: string;
    mac_address?: string;
    name?: string;
    app_eui?: string;
    dev_address?: string;
    app_skey?: string;
    nwk_skey?: string;
    is_send?: boolean;
    sleep_time?: number;
    data_send?: string;
}
