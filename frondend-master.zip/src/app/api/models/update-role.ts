/* tslint:disable */

/**
 */
export class UpdateRole {
    _id?: number;
    role_name?: string;
}
