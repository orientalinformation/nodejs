/* tslint:disable */

/**
 */
export class Temperature {
    date?: string;
    value?: string;
}
