/* tslint:disable */

/**
 */
export class CreateCompany {
    _id?: number;
    name_company?: string;
    address?: string;
    tax_number?: string;
    phone?: string;
}
