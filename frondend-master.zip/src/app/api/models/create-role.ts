/* tslint:disable */

/**
 */
export class CreateRole {
    role_name?: string;
}
