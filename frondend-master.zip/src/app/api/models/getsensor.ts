/* tslint:disable */

/**
 */
export class Getsensor {
    temperature?: number;
    accelerometer?: string;
    humidity?: string;
}
