/* tslint:disable */

/**
 */
export class CreateProduct {
    product_type_id?: number;
    company_id?: number;
    product_status_id?: number;
    name?: string;
    description?: string;
    rent_price?: number;
    manufacture_date?: string;
}
