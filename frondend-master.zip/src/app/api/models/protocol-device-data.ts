/* tslint:disable */

/**
 */
export class ProtocolDeviceData {
    lora_version?: number;
    AppNonce?: string;
    DevNonce?: string;
    NetID?: string;
    best_gateway_id?: string;
    gateways?: number;
    DevAddr?: string;
    noise?: number;
    port?: number;
    rssi?: number;
    sf?: number;
    signal?: number;
    snr?: number;
}
