/* tslint:disable */

/**
 */
export class Gw {
    _id?: number;
    name_gw: string;
    IP_public: string;
    MAC_add: string;
    OS: string;
}
