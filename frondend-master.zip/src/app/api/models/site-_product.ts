/* tslint:disable */
import { Site_properties } from './site-_properties';

/**
 */
export class Site_product {
    name?: string;
    alerts?: number[];
    chantier_total?: number;
    properties?: Site_properties[];
}
