/* tslint:disable */

/**
 */
export class Schedule {
    _id:string;
    createtime:Date;
    message:string;
}
