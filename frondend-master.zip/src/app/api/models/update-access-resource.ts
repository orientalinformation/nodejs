/* tslint:disable */

/**
 */
export class UpdateAccessResource {
    id?: number;
    name?: string;
    description?: string;
}
