/* tslint:disable */

/**
 */
export class UpdateAccessControl {
    id?: number;
    role_id?: number;
    resource_id?: number;
}
