/* tslint:disable */

/**
 */
export class UpdateUnit {
    id?: number;
    name?: string;
}
