/* tslint:disable */

/**
 */
export class UpdateDeviceData {
    id?: number;
    device_id?: number;
    data_receive?: string;
}
