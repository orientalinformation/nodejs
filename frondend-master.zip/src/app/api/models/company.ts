/* tslint:disable */

/**
 */
export class Company {
    _id?: number;
    name_company?: string;
    address?: string;
    tax_number?: string;
    phone?: string;
    
}
