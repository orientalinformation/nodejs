/* tslint:disable */

/**
 */
export class Unit {
    id?: number;
    name?: string;
}
