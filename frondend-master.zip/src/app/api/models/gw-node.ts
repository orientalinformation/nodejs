/* tslint:disable */

/**
 */
export class GwNode {
    _id?: number;
    id_company:number;
    id_gw:number;
    id_node:number;
}
