/* tslint:disable */

/**
 */
export class AccessResource {
    id?: number;
    name?: string;
    description?: string;
}
