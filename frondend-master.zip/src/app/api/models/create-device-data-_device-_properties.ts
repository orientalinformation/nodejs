/* tslint:disable */

/**
 */
export class CreateDeviceData_device_properties {
    appeui?: string;
    deveui?: string;
}
