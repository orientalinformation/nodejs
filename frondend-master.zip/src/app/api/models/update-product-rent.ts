/* tslint:disable */

/**
 */
export class UpdateProductRent {
    id?: number;
    product_id?: number;
    company_id?: number;
    transfer_numofdate?: number;
    rent_date?: string;
    expired_date?: string;
    cmt?: string;
    ref_name?: string;
}
