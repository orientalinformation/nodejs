/* tslint:disable */

/**
 */
export class DeviceAttachment {
    id?: number;
    product_id?: number;
    device_id?: number;
}
