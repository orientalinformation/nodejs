/* tslint:disable */

/**
 */
export class UpdateSite {
    lng?: number;
    id?: number;
    name?: string;
    address?: string;
    lat?: number;
    company_id?: number;
    area?: number;
    area_ml?: number;
    max_radius?: number;
    city_code?: string;
    city_name?: string;
}
