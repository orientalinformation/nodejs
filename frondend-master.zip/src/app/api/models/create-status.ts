/* tslint:disable */

/**
 */
export class CreateStatus {
    name?: string;
    description?: string;
}
