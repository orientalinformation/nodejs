/* tslint:disable */

/**
 */
export class ProductStatus {
    id?: number;
    name?: string;
    description?: string;
}
