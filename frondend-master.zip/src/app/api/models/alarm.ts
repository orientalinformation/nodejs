/* tslint:disable */

/**
 */
export class Alarm {
    _id?: number;
    name_node?: string;
    
}
