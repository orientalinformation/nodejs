/* tslint:disable */

/**
 */
export class CreateDeviceAttachment {
    product_id?: number;
    device_id?: number;
}
