/* tslint:disable */

/**
 */
export class CreateStorage {
    rent_area_ml?: number;
    company_id?: number;
    area?: number;
    rent_area?: number;
    area_ml?: number;
    name?: string;
    max_radius?: number;
    lat?: number;
    lng?: number;
    city_code?: string;
    city_name?: string;
}
