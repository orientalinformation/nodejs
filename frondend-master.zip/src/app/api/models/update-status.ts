/* tslint:disable */

/**
 */
export class UpdateStatus {
    id?: number;
    name?: string;
    description?: string;
}
