/* tslint:disable */

/**
 */
export class Login {
    name_user?: string;
    password?: string;
}
