/* tslint:disable */

/**
 */
export class ChangePasswordUser {
    current_password?: string;
    new_password?: string;
    confirm_password?: string;
}
