/* tslint:disable */

/**
 */
export class CreateProductStatus {
    name?: string;
    description?: string;
}
