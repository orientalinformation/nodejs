/* tslint:disable */

/**
 */
export class CreateUser {
    role_id?: number;
    company_id?: number;
    username?: string;
    password?: string;
    confirm_password?: string;
    email?: string;
    full_name?: string;
    phone_number?: string;
}
