/* tslint:disable */

/**
 */
export class CreateAccessResource {
    name?: string;
    description?: string;
}
