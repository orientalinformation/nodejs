/* tslint:disable */
import { Facturation_format } from './facturation-_format';

/**
 */
export class Facturation {
    name?: string;
    format?: Facturation_format[];
}
