/* tslint:disable */
import { Injectable } from '@angular/core';

/**
 * Contains global configuration for API services
 */
@Injectable()
export class ApiConfiguration {
  // rootUrl: string = "http://localhost:8080/api";
  rootUrl: string = "http://159.65.10.71:8888/";
  // rootUrl: string = "http://ifactory.dfm-europe.com:8888/";

  
}
