import { Component, OnInit, ElementRef, ViewChild, AfterViewInit, HostListener, PipeTransform, Pipe } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import * as $ from 'jquery';
import { Directive } from '@angular/core/src/metadata/directives';

import { LatLng, LatLngBounds, LatLngBoundsLiteral } from '@agm/core';
import { Polyline, Circle, LatLngLiteral } from '@agm/core/services/google-maps-types';
import { MapsAPILoader } from '@agm/core/services/maps-api-loader/maps-api-loader';
import { AgmMap } from '@agm/core/directives/map';
import { GoogleMap } from '@agm/core/services/google-maps-types';
import { GoogleMapsAPIWrapper } from '@agm/core';
import { Subject } from 'rxjs/Subject';
import { Location } from '@angular/common';
// import { Pipe } from '@angular/core';
// import { PipeTransform } from '@angular/core';
import { ModalModule, BsModalService } from 'ngx-bootstrap/modal';
import { CommonService } from '../../../../shared/common.service';



import { GwService } from '../../../../api/services/gw.service';
import { Gw } from '../../../../api/models/gw';

import { Locale } from '../../../../locale';
import { NgClass } from '@angular/common';

import { PageChangedEvent } from 'ngx-bootstrap/pagination';
@Component({
  selector: 'app-listgw',
  templateUrl: './listgw.component.html',
  styleUrls: ['./listgw.component.css']
})
export class ListgwComponent implements OnInit {

  public gw: Gw = new Gw();
  public updateGw: Gw = new Gw();
  public editGw: Gw;
  public gws: Gw[] = [];
  public keySearch:string ="";
  allIdChecked = [];

  paginations = [];

  center: any;
  showList: Boolean = false;
  zoom: Number = 14;
  bounds: LatLngBounds = null;
  coordinate: LatLngBoundsLiteral;
  infoWindowIsOpen: Boolean = false;
  lat: Number = 46.7894076;
  lng: Number = 0.1676793;
  id: Number = 1;
  capteurInfo: any = {
    identifiant: '',
    dernierMSC: '',
    statut: ''
  };
  storageInfo: any = {
    nom: '',
    disponible: '',
    loue: '',
    capteurs: ''
  };
  public storageList: Storage[];
  storageIcon = {
    url: '/assets/images/database.svg',
    scaledSize: {
      height: 90,
      width: 90
    }
  };
  listShowing = '';
  openStorageInfoWindow = false;
  isShowDetail = false;
  selectTab = 0;
  type = 'capteur';
  googleMarkers: any = [];
  currentZoom: number;

  constructor(
    private router: Router,
    private apigwService: GwService,
    private commonService: CommonService,
    private modalService: BsModalService,
    private locale: Locale,
  ) { }

  ngOnInit() {
    this.renderView();
  }

  renderView(){
    this.getAllGw();
  };

  pageChanged(event: PageChangedEvent): void {
    const startItem = (event.page - 1) * event.itemsPerPage;
    const endItem = event.page * event.itemsPerPage;
    this.paginations = this.gws.slice(startItem, endItem);
    // console.log(this.users);
  }
  getAllGw() {
    
    this.apigwService.listGw().subscribe(
      data => {
        this.gws = data;
        this.paginations = this.gws.slice(0, 10);
        // console.log(this.gws);
        // console.log(this.companies);
        data.forEach(e => {
         
          
        });
        
      }
    );
  }

  getUpdateGw( updateGw: Gw){
    this.updateGw = {
      _id: updateGw._id,
      name_gw: updateGw.name_gw,
      IP_public: updateGw.IP_public,
      MAC_add: updateGw.MAC_add,
      OS: updateGw.OS,
    };
    
  };

  getIdChecked(e,id){
    // console.log(e.target.checked);
    if (e.target.checked) {
      this.allIdChecked.push(id);
    }  else {
      this.allIdChecked.splice(this.allIdChecked.indexOf(id), 1);
    }
    // console.log(this.allIdChecked);
  }

  deleteAll(){
    if(this.allIdChecked.length>0 ) {
      if(confirm("Are you sure delete")){
        for (let index = 0; index < this.allIdChecked.length; index++) {
          this.apigwService.deleteGw(this.allIdChecked[index]).subscribe(
            response => {
              this.commonService.notifySuccess(this.locale.CONGRATULATION, this.locale.Delete_success, 1500);
              
              this.renderView();
              this.allIdChecked=[];
            },
            err => {
              this.commonService.notifyError(this.locale.SORRY, this.locale.Error, 1500);
            }
          )
        }
      }
    }else {
      this.commonService.notifyError(this.locale.SORRY, "Selected GW Delete", 1500);
    }
  };

  public filterItems(query) {
    return this.gws.filter(function(el) {
        return el.name_gw.toLowerCase().indexOf(query.toLowerCase())  > -1;
    })
    
  }

  public seachName (){

    this.apigwService.listGw().subscribe(
      data => {
        this.gws = data;
        this.gws = (this.filterItems(this.keySearch));
        this.paginations = this.gws.slice(0, 10);
      }
    );
  }

  nameExists(value,id) {
    let count = 1;
    this.gws.forEach(el => {
      if( el.name_gw.toLowerCase() == value.toLowerCase() &&  el._id == id ){
        count = 1;
        
      } else if ( el.name_gw.toLowerCase() == value.toLowerCase() &&  el._id != id ) {
        count += 1;
        return count;
      }
    }); 
    return count;
  }


  save() {
    
    if ( !this.updateGw._id ||  this.gw._id <1 ) {
      this.commonService.notifyError(this.locale.SORRY, this.locale.Ip_is_required, 1500);
    }

    else if ( !this.updateGw.name_gw || !this.updateGw.name_gw.trim() ) {
      this.commonService.notifyError(this.locale.SORRY, this.locale.NAME_IS_REQUIRED, 1500);
    }

    else if ( this.nameExists( this.updateGw.name_gw, this.updateGw._id ) > 1 ) {
      this.commonService.notifyError(this.locale.SORRY, this.locale.Name_Existed, 1500);
    }

    else if (!this.updateGw.IP_public || !this.updateGw.IP_public.trim()) {
      this.commonService.notifyError(this.locale.SORRY, this.locale.Ip_is_required, 1500);
    }
    
    else if ( !this.updateGw.MAC_add || !this.updateGw.MAC_add.trim()) {
      this.commonService.notifyError(this.locale.SORRY, this.locale.Mac_is_required, 1500);
    }

    else if ( !this.updateGw.OS || !this.updateGw.OS.trim()) {
      this.commonService.notifyError(this.locale.SORRY, this.locale.OS_is_required, 1500);
    }
   
    
    else {
      // console.log(this.gw);
      this.apigwService.updateGw(this.updateGw)
        .subscribe(
          response => {
            this.commonService.notifySuccess(this.locale.CONGRATULATION, this.locale.Add_success, 1500);
            this.renderView();
          },
          err => {
            this.commonService.notifyError(this.locale.SORRY, this.locale.Error, 1500);
          }
        );
    }
  }



}
