import { Component, OnInit, ElementRef, ViewChild, AfterViewInit, HostListener, PipeTransform, Pipe } from '@angular/core';
import { FormControl } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { DatePipe,CommonModule } from '@angular/common';
import * as $ from 'jquery';
import { LatLng, LatLngBounds, LatLngBoundsLiteral } from '@agm/core';
import { Polyline, Circle, LatLngLiteral } from '@agm/core/services/google-maps-types';
import { MapsAPILoader } from '@agm/core/services/maps-api-loader/maps-api-loader';
import { AgmMap } from '@agm/core/directives/map';
import { GoogleMap } from '@agm/core/services/google-maps-types';
import { GoogleMapsAPIWrapper } from '@agm/core';
import { Subject } from 'rxjs/Subject';
import { Location } from '@angular/common';

import { Directive } from '@angular/core/src/metadata/directives';

import { ModalModule, BsModalService } from 'ngx-bootstrap/modal';
import { CommonService } from '../../../../shared/common.service';

import { NodeService } from '../../../../api/services/node.service';
import { Node } from '../../../../api/models/node';
import { Nodedata } from '../../../../api/models/node-data';

import { Getsensor } from '../../../../api/models/getsensor';
import { Temperature } from '../../../../api/models/temperature';
import { Accelerometer } from '../../../../api/models/accelerometer';

import { GroupsService } from '../../../../api/services/groups.service';
import { Group } from '../../../../api/models/group';

import { Locale } from '../../../../locale';
import { NgClass } from '@angular/common';
import { noComponentFactoryError } from '@angular/core/src/linker/component_factory_resolver';

import { SelectComponent } from 'ng2-select';

import { PageChangedEvent } from 'ngx-bootstrap/pagination';

// import { $,  } from 'protractor';
import { randomBytes } from 'crypto';

import { DatepickerModule, BsDatepickerModule } from 'ngx-bootstrap/datepicker';

import { formatDate } from 'ngx-bootstrap/chronos/format';


@Component({
  selector: 'app-listnode',
  templateUrl: './listnode.component.html',
  styleUrls: ['./listnode.component.css']
})
export class ListnodeComponent implements OnInit {

  public node: Node = new Node();

  public getsensors: Getsensor[] = [];
  public temperatures: Temperature[] = [];
  public accelerometers: Accelerometer[] = [];

  
  public updateNode: Node = new Node();

  public nodeData: Nodedata = new Nodedata();

  public nodes: Node[] = [];
  public items:any = [] ;

  public group:Group = new Group(); 
  public groups:Group[]= [] ;
  lat;
  long;
  allIdChecked=[];
  
  paginations = [];
  
  selectGroup = 0;
  keySearch = "";

  profile = false;
  selectStatus = null;
  arrStatus = [{"text":'active',"id":'true'},{"text":'not active',"id":'false'}]
  
  @ViewChild('gr') ngSelect: SelectComponent;
  @ViewChild('status') ngSelectStatus: SelectComponent;
  dateRang: Date;

  daterangepickerModel: Date[];
  
 
  constructor(
    private router: Router,
    private apiNodeService: NodeService,
    private apiGroupService: GroupsService,
    private commonService: CommonService,
    private modalService: BsModalService,
    private locale: Locale,

  ) { }


  ngOnInit() {
    this.renderView();
    
  }
 
  onValueChange(value: Date): void {

    this.dateRang = value;
    
    let pipe = new DatePipe('en-US');
    
    // this.dateRang[1] = pipe.transform(this.dateRang[1], 'yyyy/mm/dd');
    // this.dateRang[0] = pipe.transform(this.dateRang[0], 'yyyy/mm/dd');
    // let dateCount  = this.dateRang[1] - this.dateRang[0];
    // console.log(this.dateRang[0]);
    // console.log(this.dateRang[1]);
    // console.log(dateCount/(1000 * 3600 * 24));
    
  }

  onchangeDraw(value):void {
    
    if(value != 'accelerometer') {

      this.apiNodeService.listDraw(this.keySearch,value).subscribe(
        res => {
          this.temperatures = res;
          console.log(this.temperatures);
          
          var data = new google.visualization.DataTable();
          data.addColumn('string', 'X');
          data.addColumn('number', 'value');
          let arr = [];
          //   for (let index = 0; index < 61; index++) {
          //       arr.push([index,Math.floor((Math.random() * 100) + 1)]);
          //   }
          this.temperatures.forEach(e => {
             
            console.log(e.date.split("T"));
            arr.push([e.date,e.value]);
          });
          data.addRows(arr);
          // Set chart options
          var options = {
            "width": 800,
            'height':300,
            hAxis: {
              title: 'Date'
            },
            vAxis: {
              title: ''
            }
          };
          // Instantiate and draw our chart, passing in some options.
          var chart = new google.visualization.LineChart(document.getElementById('chart_div'));
          chart.draw(data, options);
        }
      );
    } else {
      
      this.apiNodeService.listDrawAccelerometer(this.keySearch,value).subscribe(
        res => {
          this.accelerometers = res;
          // console.log(this.temperatures);
          let X,Y,Z;
          var data = new google.visualization.DataTable();
          data.addColumn('string', 'Date');
          data.addColumn('number', 'X');
          data.addColumn('number', 'Y');
          data.addColumn('number', 'Z');
          let arr = [];
          
          this.accelerometers.forEach(e => {

            arr.push([e.date,e.value.X,e.value.Y,e.value.Z]);
          });
          data.addRows(arr);
          // Set chart options
          var options = {
            "width": 800,
            'height':300,
            hAxis: {
              title: 'Date'
            },
            vAxis: {
              title: ''
            }
          };
          // Instantiate and draw our chart, passing in some options.
          var chart = new google.visualization.LineChart(document.getElementById('chart_div'));
          chart.draw(data, options);
        }
      );
    }
  }

  
  renderView(){
    this.getAllGroup();
    this.getAllNode();
    google.charts.load('current', {'packages':['corechart','line']});
      // Set a callback to run when the Google Visualization API is loaded.
    google.charts.setOnLoadCallback(this.drawChart);
    

  }

  pageChanged(event: PageChangedEvent): void {
    const startItem = (event.page - 1) * event.itemsPerPage;
    const endItem = event.page * event.itemsPerPage;
    this.paginations = this.nodes.slice(startItem, endItem);
    
  }

  getAllNode() {

    this.apiNodeService.listNode().subscribe(
      data => {
        this.nodes = data;
        
        this.paginations = this.nodes.slice(0, 10);
      }
    );
  }

  getAllGroup() {

    this.items = [];
    this.apiGroupService.listGroups().subscribe(
      data => {
        this.groups = data;
        data.forEach(e => {
          
          this.items.push( {"text":e.group_name,"id":e._id});
          
          this.ngSelect.items = this.items;

        });
        
        
      }
    );
  }
  nameExists(value,id) {
    let count = 1;
    this.nodes.forEach(el => {
      if( el.name_node.toLowerCase() == value.toLowerCase() &&  el._id == id ){
        count = 1;
      } else if ( el.name_node.toLowerCase() == value.toLowerCase() &&  el._id != id ) {
        count += 1;
        return count;
      }
    }); 
    return count;
    
  }

 

  save() {
    
    if (this.updateNode._id == undefined ||  this.updateNode._id <1 ) {
      this.commonService.notifyError(this.locale.SORRY, this.locale.ID_IS_REQUIRED, 1500);
    }

    else if ( !this.updateNode.name_node || !this.updateNode.name_node.trim() ) {
      this.commonService.notifyError(this.locale.SORRY, this.locale.NAME_IS_REQUIRED, 1500);
    }

    else if (this.nameExists(this.updateNode.name_node,this.updateNode._id) > 1 ) {
      this.commonService.notifyError(this.locale.SORRY, this.locale.Name_Existed, 1500);
    }

    else if ( this.selectStatus == null ) {
      this.commonService.notifyError(this.locale.SORRY, this.locale.Status_is_required, 1500);
    }
    else if ( !this.updateNode.Manufacture || !this.updateNode.Manufacture.trim() ) {
      this.commonService.notifyError(this.locale.SORRY, this.locale.Manufactuer_is_required , 1500);
    }
    else if ( !this.updateNode.Codec || !this.updateNode.Codec.trim()) {
      this.commonService.notifyError(this.locale.SORRY, this.locale.Codec_is_required , 1500);
    }
    else if ( !this.updateNode.OS || !this.updateNode.OS.trim()) {
      this.commonService.notifyError(this.locale.SORRY, this.locale.OS_is_required, 1500);
    }
    else if (this.selectGroup == 0 || this.selectGroup == undefined ) {
      this.commonService.notifyError(this.locale.SORRY, this.locale.Group_is_required , 1500);
    }
    else if ( !this.updateNode.dev_eui || !this.updateNode.dev_eui.trim()) {
      this.commonService.notifyError(this.locale.SORRY, this.locale.Dev_Eui_is_required, 1500);
    }
    else if (!this.updateNode.app_eui || !this.updateNode.app_eui.trim() ) {
      this.commonService.notifyError(this.locale.SORRY, this.locale.App_Eui_is_required , 1500);
    }
    else if ( !this.updateNode.app_key || !this.updateNode.app_key.trim() ) {
      this.commonService.notifyError(this.locale.SORRY, this.locale.App_Key_is_required, 1500);
    }
    
    // else if ( !this.updateNode.Profile || this.updateNode.Profile.trim() ) {
    //   this.commonService.notifyError(this.locale.SORRY, this.locale.Profile_is_required, 1500);
    // }

    else {
      this.updateNode.id_group = this.selectGroup;
      this.updateNode.status = this.selectStatus;

      this.apiNodeService.updateNode(this.updateNode)
        .subscribe(
          response => {
            this.commonService.notifySuccess(this.locale.CONGRATULATION, this.locale.Update_success, 1500);
            this.renderView();
          },
          err => {
            this.commonService.notifyError(this.locale.SORRY, this.locale.Error, 1500);
          }
        );
    }
  }

  deleteAll(){
    if(this.allIdChecked.length>0 ) {
      if(confirm("Are you sure delete")){
        for (let index = 0; index < this.allIdChecked.length; index++) {
          this.apiNodeService.deleteNode(this.allIdChecked[index]).subscribe(
            response => {
              this.commonService.notifySuccess(this.locale.CONGRATULATION, this.locale.Delete_success, 1500);
              
              this.renderView();
              this.allIdChecked=[];
            },
            err => {
              this.commonService.notifyError(this.locale.SORRY, this.locale.Error, 1500);
            }
          )
        }
      }
    }else {
      this.commonService.notifyError(this.locale.SORRY, "Selected user delete", 1500);
    }
  };

  getUpdateNode( updateNode: Node){
    this.updateNode = {
      _id: updateNode._id,
      name_node: updateNode.name_node,
      status: updateNode.status,
      Manufacture: updateNode.Manufacture,
      Codec: updateNode.Codec,
      OS: updateNode.OS,
      id_group: updateNode.id_group,
      dev_eui: updateNode.dev_eui,
      app_eui: updateNode.app_eui,
      app_key: updateNode.app_key,
      Profile: updateNode.Profile,
      

    };

    this.profile = true;
    let activeGroup = [];
    let text="";
    if(this.updateNode.status == 'true') {
      text = 'Active';
    } else {
      text = "Not active"
    }
    this.ngSelectStatus.active =[{ "id": this.updateNode.status,"text":text }];
    this.selectStatus = this.updateNode.status;
    this.apiGroupService.listGroups().subscribe(
      data => {
        this.groups = data;
        data.forEach(e => {
          
          if(this.updateNode.id_group == e._id){
            activeGroup.push({'text':e.group_name,"id":e._id});
            // console.log(activeGroup);
            this.ngSelect.active = activeGroup;
            this.selectGroup = e._id ;
          }
        });
      }
    );
  };

  public filterItems(query) {
    return this.nodes.filter(function(el) {
        // return el.name_node.toLowerCase().indexOf(query.toLowerCase())  > -1;
    })
    
  }
  
  getGeo(name){

    this.nodes.forEach(e => {
      document.getElementById(e.name_node).style.color = "#007bff" ;  
    });
    
    document.getElementById(name).style.color = "#23527c" ;
    
    this.apiNodeService.getNodeByName(name).subscribe(
      data => {
        this.nodeData = data;

        

        if(data != null){
          this.lat = this.nodeData.message[1].value.latitude;
          this.long = this.nodeData.message[1].value.longitude;
        }else {
          this.lat=0;
          this.long=0;
          // console.log(this.lat);
          this.commonService.notifyError(this.locale.SORRY, " "+ name +" doesn't exist", 2000);
        }
        // console.log(data);
        // this.paginations = this.nodes.slice(0, 10);
      },
      error => { 
        this.lat=0;
        this.long=0;
        // console.log(this.lat);
        this.commonService.notifyError(this.locale.SORRY, "Name ' "+ this.keySearch +" ' doesn't exist", 2000);
        // console.log('Received an errror: ' + error.status);
    
      }
      
    );
  }

  public seachName (){

    // this.apiNodeService.listNode().subscribe(
    //   data => {
    //     this.nodes = data;
    //     this.nodes = (this.filterItems(this.keySearch));
    //     this.paginations = this.nodes.slice(0, 10);
    //   }
    // );
    
    this.apiNodeService.getNodeByName(this.keySearch).subscribe(
      data => {
        this.nodeData = data;
        this.lat = this.nodeData.message[1].value.latitude;
        this.long = this.nodeData.message[1].value.longitude;
        // console.log(data);
        // this.paginations = this.nodes.slice(0, 10);
      },
      error => { 
        this.lat=0;
        this.long=0;
        // console.log(this.lat);
        this.commonService.notifyError(this.locale.SORRY, "Name ' "+ this.keySearch +" ' doesn't exist", 2000);
        // console.log('Received an errror: ' + error.status);
    
      }
      
    );

  }



  getIdChecked(e,id){
    // console.log(e.target.checked);
    if (e.target.checked) {
      this.allIdChecked.push(id);
    }  else {
      this.allIdChecked.splice(this.allIdChecked.indexOf(id), 1);
    }
    // console.log(this.allIdChecked);
  }

  public selectedGroup(value:any):void {
    this.selectGroup = value.id;
  }
  public selectedStatus(value:any):void {
    this.selectStatus = value.id;
    
  }
  // private get disabledV():string {
  //   // return this._disabledV;
  // }
 
  private set disabledV(value:string) {
    // this._disabledV = value;
    // this.disabled = this._disabledV === '1';
  }
 
  public removed(value:any):void {
    // console.log('Removed value is: ', value);
  }
 
  public typed(value:any):void {
    // console.log('New search input: ', value);
  }
 
  public refreshValue(value:any):void {
    // this.value = value;
  }

  getChart(name){
    
    if(name) {
      this.apiNodeService.listGetsensor(name).subscribe(
        data => {
          this.getsensors = data;
          
          // this.paginations = this.nodes.slice(0, 10);
        },
        error => { 
          // this.commonService.notifyError(this.locale.SORRY, "Name Node dosen't existed", 1500);   
        }
      );
    }else {
      // this.commonService.notifyError(this.locale.SORRY, "Enter name Node", 1500);    
      
    }
  }

  drawChart (){

    
  }

}
