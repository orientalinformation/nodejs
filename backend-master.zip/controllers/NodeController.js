var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');

router.use(bodyParser.urlencoded({ extended: true }));
router.use(bodyParser.json());

var Node = require('../models/Node');
var Schedule = require('../models/Schedule');

// CREATES A NEW NODE
router.post('/create', function (req, res) {
    Node.findById(req.body._id, function(err, node) {
        if (err) return res.status(500).send(err);
        if (node) return res.status(404).send('ID is already taken');
        
        var newNode            = new Node();          
        newNode._id            = req.body._id,
        newNode.name_node      = req.body.name_node,
        newNode.status         = req.body.status,
        newNode.OS             = req.body.OS,
        newNode.dev_eui        = req.body.dev_eui,
        newNode.app_eui        = req.body.app_eui,
        newNode.app_key        = req.body.app_key,
        newNode.id_group       = req.body.id_group,
        newNode.Manufacture    = req.body.Manufacture,
        newNode.Profile        = req.body.Profile,
        newNode.Codec          = req.body.Codec
    
        newNode.save(function(err) {
            if (err) return res.status(500).send("There was a problem adding the information to the database.");
            res.status(200).send(newNode);
        });
    });  
});

// RETURNS ALL THE NODE IN THE DATABASE
router.get('/getall', function (req, res) {
    Node.find({}, function (err, nodes) {
        if (err) return res.status(500).send("There was a problem finding the node.");
        res.status(200).send(nodes);
    });
});

// GETS A SINGLE NODE BY ID FROM THE DATABASE
router.get('/getbyid/:id', function (req, res) {
    Node.findById(req.params.id, function (err, node) {
        if (err) return res.status(500).send("There was a problem finding the node.");
        if (!node) return res.status(404).send("No node found.");
        res.status(200).send(node);
    });
});

// GETS A SINGLE NODE BY NAME FROM THE DATABASE
router.get('/getbyname/:name', function (req, res) {
    Node.find({name_node: req.params.name}, function (err, node) {
        if (err) return res.status(500).send("There was a problem finding the node.");
        if (!node.length) return res.status(404).send("No node found.");
        res.status(200).send(node);
    });
});

// GETS LOCATION
router.get('/getlocation/:name', function (req, res) {
    Node.find({name_node: req.params.name}, function (err, node) {
        if (err) return res.status(500).send("There was a problem finding the node.");
        if (!node.length) return res.status(404).send("No node found.");

        var _id = node[0]._id;
        Schedule.findOne({id_node: _id}, null, {sort: {createtime: -1}}, function(req, schedule){
            res.status(200).send(schedule);
        });
    });
});

// DELETES A NODE FROM THE DATABASE
router.delete('/delete/:id', function (req, res) {
    Node.findByIdAndRemove(req.params.id, function (err, node) {
        if (err) return res.status(500).send("There was a problem deleting the node.");
        res.status(200).send("node: "+ node.node_name +" was deleted.");
    });
});

// UPDATES A SINGLE NODE IN THE DATABASE
router.put('/update/:id', function (req, res) {
    Node.findByIdAndUpdate(req.params.id, req.body, {new: true}, function (err, node) {
        if (err) return res.status(500).send("There was a problem updating the node.");
        res.status(200).send(node);
    });
});

module.exports = router;