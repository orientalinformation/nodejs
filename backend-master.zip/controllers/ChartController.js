var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');

router.use(bodyParser.urlencoded({ extended: true }));
router.use(bodyParser.json());

var Node = require('../models/Node');
var Schedule = require('../models/Schedule');

router.get('/getchart/:nameNode/:nameSensor', function (req, res) {     
    var nameNode = req.params.nameNode;
    var nameSensor = req.params.nameSensor;
   
    var currentDay = new Date();
    var yesterday = new Date();
    yesterday.setDate(currentDay.getDate() - 10);
    yesterday = yesterday.toISOString();

    Node.find({name_node: nameNode}, function (err, node) {
        if (err) return res.status(500).send("There was a problem finding the node.");
        if (!node.length) return res.status(404).send("No node found.");

        var _id = node[0]._id;
        Schedule.find({ $and: [ { id_node: _id  }, { createtime: { $gte: yesterday } } ] }, function(req, schedule){
            if (err) return res.status(500).send("There was a problem finding the schedule.");
            if (!schedule.length) return res.status(404).send("No schedule found.");

            var arr = [];
            var itemsProcessed = 0;

            schedule.forEach(e => {
                itemsProcessed++;

                var message = e.message;
                var obj = message.find(item => item.name == nameSensor);

                if (obj) {
                    var obj = {
                        "date": e.createtime,
                        "value": obj.value
                    };
    
                    arr.push(obj); 
                }

                if (itemsProcessed == schedule.length) 
                    res.status(200).send(arr);
                
            });  
        });  
    });
});

router.get('/getsensor/:nameNode', function (req, res){
    var nameNode = req.params.nameNode;
    Node.find({name_node: nameNode}, function (err, node) {
        if (err) return res.status(500).send("There was a problem finding the node.");
        if (!node.length) return res.status(404).send("No node found.");

        var _id = node[0]._id;
        Schedule.findOne({id_node: _id}, function(req, schedule){
            if (err) return res.status(500).send("There was a problem finding the schedule.");
            if (!schedule) return res.status(404).send("No schedule found.");
            
            var message = schedule.message;
        
            var arr = []
            var itemsProcessed = 0;

            message.forEach(e => {
                itemsProcessed++;

                if (e.name != "GPS" ) 
                    arr.push(e.name);
                
                if (itemsProcessed == message.length) 
                    res.status(200).send(arr);
                
            });        
        });  
    }); 
});

module.exports = router;