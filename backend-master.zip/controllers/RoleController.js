var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');

router.use(bodyParser.urlencoded({ extended: true }));
router.use(bodyParser.json());

var Role = require('../models/Role');

// CREATES A NEW ROLE
router.post('/create', function (req, res) {
    Role.findById(req.body._id, function(err, role) {
        if (err) return res.status(500).send(err);
        if (role) return res.status(404).send('ID is already taken');

        var newRole            = new Role();          
        newRole._id            = req.body._id,
        newRole.role_name      = req.body.role_name
           
        newRole.save(function(err) {
            if (err) return res.status(500).send("There was a problem adding the information to the database.");
            res.status(200).send(newRole);
        });
    });  
});

// RETURNS ALL THE ROLE IN THE DATABASE
router.get('/getall', function (req, res) {
    Role.find({}, function (err, roles) {
        if (err) return res.status(500).send("There was a problem finding the role.");
        res.status(200).send(roles);
    });
});

// GETS A SINGLE ROLE BY ID FROM THE DATABASE
router.get('/getbyid/:id', function (req, res) {
    Role.findById(req.params.id, function (err, role) {
        if (err) return res.status(500).send("There was a problem finding the role.");
        if (!role) return res.status(404).send("No role found.");
        res.status(200).send(role);
    });
});

// GETS A SINGLE ROLE BY NAME FROM THE DATABASE
router.get('/getbyname/:name', function (req, res) {
    Role.find({role_name: req.params.name}, function (err, role) {
        if (err) return res.status(500).send("There was a problem finding the role.");
        if (!role.length) return res.status(404).send("No role found.");
        res.status(200).send(role);
    });
});

// DELETES A ROLE FROM THE DATABASE
router.delete('/delete/:id', function (req, res) {
    Role.findByIdAndRemove(req.params.id, function (err, role) {
        if (err) return res.status(500).send("There was a problem deleting the role.");
        res.status(200).send("role: "+ role.role_name +" was deleted.");
    });
});

// UPDATES A SINGLE ROLE IN THE DATABASE
router.put('/update/:id', function (req, res) {
    Role.findByIdAndUpdate(req.params.id, req.body, {new: true}, function (err, role) {
        if (err) return res.status(500).send("There was a problem updating the role.");
        res.status(200).send(role);
    });
});

module.exports = router;