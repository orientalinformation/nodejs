var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');

router.use(bodyParser.urlencoded({ extended: true }));
router.use(bodyParser.json());

var GWnode = require('../models/GWnode');

// CREATES A NEW GW-Node
router.post('/create', function (req, res) {
    GWnode.findById(req.body._id, function(err, gwnode) {
        if (err) return res.status(500).send(err);
        if (gwnode) return res.status(404).send('ID is already taken');

        var newGWnode            = new GWnode();          
        newGWnode._id            = req.body._id,
        newGWnode.id_company     = req.body.id_company,
        newGWnode.id_gw          = req.body.id_gw,
        newGWnode.id_node        = req.body.id_node
    
        newGWnode.save(function(err) {
            if (err) return res.status(500).send("There was a problem adding the information to the database.");
            res.status(200).send(newGWnode);
        });
    });  
});

// RETURNS ALL THE GW-Node IN THE DATABASE
router.get('/getall', function (req, res) {
    GWnode.find({}, function (err, gwnode) {
        if (err) return res.status(500).send("There was a problem finding the GW-Node.");
        res.status(200).send(gwnode);
    });
});

// GETS A SINGLE GW-Node BY ID FROM THE DATABASE
router.get('/getbyid/:id', function (req, res) {
    GWnode.findById(req.params.id, function (err, gwnode) {
        if (err) return res.status(500).send("There was a problem finding the GW-Node.");
        if (!gwnode) return res.status(404).send("No GWNode found.");
        res.status(200).send(gwnode);
    });
});

// DELETES A GW-Node FROM THE DATABASE
router.delete('/delete/:id', function (req, res) {
    GWnode.findByIdAndRemove(req.params.id, function (err, gwnode) {
        if (err) return res.status(500).send("There was a problem deleting the GW-Node.");
        res.status(200).send("GWNode: "+ gwnode.name_gwnode +" was deleted.");
    });
});

// UPDATES A SINGLE GW-Node IN THE DATABASE
router.put('/update/:id', function (req, res) {
    GWnode.findByIdAndUpdate(req.params.id, req.body, {new: true}, function (err, gwnode) {
        if (err) return res.status(500).send("There was a problem updating the GW-Node.");
        res.status(200).send(gwnode);
    });
});

module.exports = router;