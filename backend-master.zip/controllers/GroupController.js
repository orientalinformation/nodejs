var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');

router.use(bodyParser.urlencoded({ extended: true }));
router.use(bodyParser.json());

var Group = require('../models/Group');

// CREATES A NEW GROUP
router.post('/create', function (req, res) {
    Group.findById(req.body._id, function(err, group) {
        if (err) return res.status(500).send(err);
        if (group) return res.status(404).send('ID is already taken');

        var newGroup            = new Group();          
        newGroup._id            = req.body._id,
        newGroup.id_company     = req.body.id_company,
        newGroup.group_name     = req.body.group_name
    
        newGroup.save(function(err) {
            if (err) return res.status(500).send("There was a problem adding the information to the database.");
            res.status(200).send(newGroup);
        });
    });  
});

// RETURNS ALL THE GROUP IN THE DATABASE
router.get('/getall', function (req, res) {
    Group.find({}, function (err, group) {
        if (err) return res.status(500).send("There was a problem finding the group.");
        res.status(200).send(group);
    });
});

// GETS A SINGLE GROUP BY ID FROM THE DATABASE
router.get('/getbyid/:id', function (req, res) {
    Group.findById(req.params.id, function (err, group) {
        if (err) return res.status(500).send("There was a problem finding the group.");
        if (!group) return res.status(404).send("No group found.");
        res.status(200).send(group);
    });
});

// GETS A SINGLE GROUP BY NAME FROM THE DATABASE
router.get('/getbyname/:name', function (req, res) {
    Group.find({group_name: req.params.name}, function (err, group) {
        if (err) return res.status(500).send("There was a problem finding the group.");
        if (!group.length) return res.status(404).send("No group found.");
        res.status(200).send(group);
    });
});

// DELETES A GROUP FROM THE DATABASE
router.delete('/delete/:id', function (req, res) {
    Group.findByIdAndRemove(req.params.id, function (err, group) {
        if (err) return res.status(500).send("There was a problem deleting the group.");
        res.status(200).send("group: "+ group.group_name +" was deleted.");
    });
});

// UPDATES A SINGLE GROUP IN THE DATABASE
router.put('/update/:id', function (req, res) {
    Group.findByIdAndUpdate(req.params.id, req.body, {new: true}, function (err, group) {
        if (err) return res.status(500).send("There was a problem updating the group.");
        res.status(200).send(group);
    });
});

module.exports = router;