var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');
var request = require('request');
var lora_packet = require('lora-packet');

router.use(bodyParser.urlencoded({ extended: true }));
router.use(bodyParser.json());

router.post('/joinrequest', function (req, res) {    
    
    //get message
    var message = req.body.rxpk[0].data;
   
    //encrypt
    var packet = lora_packet.fromWire(Buffer.from(message, 'base64'));
    console.log("log packet 1 " + packet);
    
    //get DevNonce
    var DevNonce = packet.getBuffers().DevNonce;
    console.log(DevNonce);
    
    //Authen DevNonce
    var devnonce = DevNonce.toString('hex');
    console.log(devnonce);


    id_node = 1;
    request.get({
        url:     'http://localhost:8888/node/getbyid/' + id_node,
        json: true,       
    }, function(error, response, body){
        
        if (body.Profile.DevNonce == devnonce) { // CHU Y nguoc lai !=
            //Create AppKey
            var AppKey = Buffer.from('B304CB0BAA52A353E819725F894D34F8', 'hex');

            //Check MIC
            var checkMIC = (lora_packet.verifyMIC(packet, null, AppKey) ? "OK" : "fail");
            console.log(checkMIC);

            //Calculate MIC based on contents
            var calculate = lora_packet.calculateMIC(packet, null, AppKey).toString('hex');
            console.log("cal MIC: " + calculate);

            //If MIC OK continue
            if (checkMIC == "OK") {

                //create AppNonce
                var AppNonce = (Math.random()*0xFFFFFF<<0).toString(16);
                AppNonce = Buffer.from(AppNonce, 'hex');

                //create NetID
                var NetID = Buffer.from("000007", 'hex');

                //generate session keys
                var sessionKeys = lora_packet.generateSessionKeys(
                    AppKey, NetID, AppNonce, DevNonce
                );
                
                //SKey
                var NwkSKey = sessionKeys.NwkSKey.toString('hex');
                var AppSKey = sessionKeys.AppSKey.toString('hex');

                
                console.log(NwkSKey);
                console.log(AppSKey);
                
                var constructedPacket = lora_packet.fromFields(
                    {
                        AppNonce: AppNonce,
                        NetID: NetID,
                        DevAddr: Buffer.from('0e341176', 'hex'),
                        DLSettings: Buffer.from('12', 'hex'),
                        RxDelay: Buffer.from('0F', 'hex'),
                        CFList: Buffer.from('11223311223311223311223311223300', 'hex'),
                    }
                    , undefined
                    , undefined
                    , AppKey
                );


                console.log("constructedPacket.toString()=\n" + constructedPacket);
                var wireFormatPacket = constructedPacket.getPHYPayload();
                console.log("wireFormatPacket.toString()=\n" + wireFormatPacket.toString('hex'));
                
                //encrypt base64
                
                var joinAccept = wireFormatPacket.toString('base64');

                console.log("base64 " + joinAccept);


                console.log("----------------------------");
                    

                //Create Profile Node
                var obj = {
                    "Message Type": "Join Request",
                    "PHYPayload": packet.getBuffers().PHYPayload.toString('hex'),
                    "MHDR" : packet.getBuffers().MHDR.toString('hex'),
                    "MACPayload" : packet.getBuffers().MACPayload.toString('hex'),
                    "MIC" : packet.getBuffers().MIC.toString('hex'),
                    "AppEUI" : packet.getBuffers().AppEUI.toString('hex'),
                    "DevEUI" : packet.getBuffers().DevEUI.toString('hex'),
                    "DevNonce" : packet.getBuffers().DevNonce.toString('hex')
                };

                console.log(obj);

                var jsonDataObj = {'Profile': obj};

                request.put({
                    url:     'http://localhost:8888/node/update/' + id_node,
                    body:    jsonDataObj,
                    json: true,       
                }, function(error, response, body){
                    
                });

                //send GW
                //continue
                console.log("end");
                res.status(200).send(joinAccept);
                
            } 
        }
    });

    
    

});

 // 400403020120030001dcff6a78ee8aa776afcfedb64eeacee30ba7e8d8f0d12057bd3e1fd21931d4bc6b0b52d2f0d21622d76d904d0421a9d516368986e90e486c
router.post('/uplink', function (req, res) { 
   
    //get message
    var message = req.body.value;
    
    var packet = lora_packet.fromWire(Buffer.from(message, 'hex'));
    
    var NwkSKey = Buffer.from('44024241ed4ce9a68c6a8bc055233fd3', 'hex');
    var AppSKey = Buffer.from('ec925802ae430ca77fd3dd73cb2cc588', 'hex');

    var payload = lora_packet.decrypt(packet, AppSKey, NwkSKey).toString();

    var jsonDataObj = {'value': payload};

    request.post({
        url:     'http://localhost:8888/schedule/createdata',
        body:    jsonDataObj,
        json: true,       
    }, function(error, response, body){
        
    });

    res.status(200).send();
});

router.post('/downlink', function (req, res) { 

    var NwkSKey = Buffer.from('44024241ed4ce9a68c6a8bc055233fd3', 'hex');
    var AppSKey = Buffer.from('ec925802ae430ca77fd3dd73cb2cc588', 'hex');

    var constructedPacket = lora_packet.fromFields({
        MType: 'Unconfirmed Data Down',   
        DevAddr: Buffer.from('01020304', 'hex'), 
        FCtrl: {
            ADR: false,      
            ACK: true,        
            ADRACKReq: false, 
            FPending: false   
        },
        FCnt: Buffer.from('0003', 'hex'), 
        payload: 'test'
    }
    , AppSKey
    , NwkSKey 
    );

    console.log("constructedPacket.toString()=\n" + constructedPacket);
    var wireFormatPacket = constructedPacket.getPHYPayload();
    console.log("wireFormatPacket.toString()=\n" + wireFormatPacket.toString('hex'));

    res.status(200).send();
});

module.exports = router;