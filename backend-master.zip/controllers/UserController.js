var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');
var crypto = require('crypto-js');

router.use(bodyParser.urlencoded({ extended: true }));
router.use(bodyParser.json());

var User = require('../models/User');

// CREATES A NEW USER
router.post('/create', function (req, res) {
    User.find({ $or: [ {_id:req.body._id}, {name_user:req.body.name_user} ] }, function(err, user) {
        if (err) return res.status(500).send(err);
        if (user.length!=0) {
            if(user[0]._id == req.body._id) return res.status(404).send('ID already exists');  
            else return res.status(404).send('Username already exists');
        }
        
        // Decode password
        req.body.password = crypto.AES.decrypt(req.body.password, 'dfmsecret');
        req.body.password = req.body.password.toString(crypto.enc.Utf8);

        var newUser             = new User();
        newUser._id             = req.body._id,
        newUser.id_company      = req.body.id_company,
        newUser.id_role         = req.body.id_role,
        newUser.name_user       = req.body.name_user,
        newUser.email           = req.body.email,
        newUser.password        = req.body.password
               
        newUser.save(function(err) {
            if (err) return res.status(500).send("There was a problem adding the information to the database.");
            res.status(200).send(newUser);
        });
    });  
});

// RETURNS ALL THE USER IN THE DATABASE
router.get('/getall', function (req, res) {
    User.find({}, function (err, users) {
        if (err) return res.status(500).send("There was a problem finding the user.");
        res.status(200).send(users);
    });
});

// GETS A SINGLE USER BY ID FROM THE DATABASE
router.get('/getbyid/:id', function (req, res) {
    User.findById(req.params.id, function (err, user) {
        if (err) return res.status(500).send("There was a problem finding the user.");
        if (!user) return res.status(404).send("No user found.");
        res.status(200).send(user);
    });
});

// GETS A SINGLE USER BY NAME FROM THE DATABASE
router.get('/getbyname/:name', function (req, res) {
    User.find({name_user: req.params.name}, function (err, user) {
        if (err) return res.status(500).send("There was a problem finding the user.");
        if (!user.length) return res.status(404).send("No user found.");
        res.status(200).send(user);
    });
});

// DELETES A USER FROM THE DATABASE
router.delete('/delete/:id', function (req, res) {
    User.findByIdAndRemove(req.params.id, function (err, user) {
        if (err) return res.status(500).send("There was a problem deleting the user.");
        res.status(200).send("user: "+ user.name_user +" was deleted.");
    });
});

// UPDATES A SINGLE USER IN THE DATABASE
router.put('/update/:id', function (req, res) {
    // Decode password
    req.body.password = crypto.AES.decrypt(req.body.password, 'dfmsecret');
    req.body.password = req.body.password.toString(crypto.enc.Utf8);

    User.findByIdAndUpdate(req.params.id, req.body, {new: true}, function (err, user) {
        if (err) return res.status(500).send("There was a problem updating the user.");
        res.status(200).send(user);
    });
});

// LOGIN USER
router.post('/login', function (req, res) {
    // Decode password
    req.body.password = crypto.AES.decrypt(req.body.password, 'dfmsecret');
    req.body.password = req.body.password.toString(crypto.enc.Utf8);

    User.findOne({name_user: req.body.name_user, password: req.body.password}, function(err, user){
        if (err) return res.status(500).send("There was a problem finding the user.");
        if (!user) return res.status(404).send("No user found.");

        res.status(200).send(user);
    })
});

module.exports = router;