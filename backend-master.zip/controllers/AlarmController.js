var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');
var request = require('request');

router.use(bodyParser.urlencoded({ extended: true }));
router.use(bodyParser.json());

var Node = require('../models/Node');
var Schedule = require('../models/Schedule');

router.get('/getall', function (req, res) {     
    var currentDay = new Date();
  
    var yesterday = new Date();
    yesterday.setDate(currentDay.getDate() - 1);
    yesterday = yesterday.toISOString();
    

    Node.find({status: "true"}, function (err, node) {
        if (err) return res.status(500).send("There was a problem finding the node.");
        if (!node.length) return res.status(404).send("No node found.");

        var arr = [];
        var itemsProcessed = 0;

        node.forEach(e => {           
            var id_node = e._id.toString();
           
            Schedule.find({ $and: [ { id_node: id_node  }, { createtime: { $gte: yesterday } } ] }, function (err, schedule) {
                itemsProcessed++;

                if (!schedule.length) {

                    var obj = {
                        "_id": e._id,
                        "name_node": e.name_node 
                    };    
                    
                    arr.push(obj); 
                }

                if (itemsProcessed == node.length) 
                    res.status(200).send(arr);
                    
            }); 
        });      
    });
});

module.exports = router;