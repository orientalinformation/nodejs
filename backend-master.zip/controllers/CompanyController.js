var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');

router.use(bodyParser.urlencoded({ extended: true }));
router.use(bodyParser.json());

var Company = require('../models/Company');

// CREATES A NEW COMPANY
router.post('/create', function (req, res) {
    Company.findById(req.body._id, function(err, company) {
        if (err) return res.status(500).send(err);
        if (company) return res.status(404).send('ID is already taken');
        
        var newCompany            = new Company();          
        newCompany._id            = req.body._id,
        newCompany.name_company   = req.body.name_company,
        newCompany.address        = req.body.address,
        newCompany.tax_number     = req.body.tax_number,
        newCompany.phone          = req.body.phone

        newCompany.save(function(err) {
            if (err) return res.status(500).send("There was a problem adding the information to the database.");
            res.status(200).send(newCompany);
        });
    });  
});

// RETURNS ALL THE COMPANY IN THE DATABASE
router.get('/getall', function (req, res) {
    Company.find({}, function (err, companies) {
        if (err) return res.status(500).send("There was a problem finding the company.");
        res.status(200).send(companies);
    });
});

// GETS A SINGLE COMPANY BY ID FROM THE DATABASE
router.get('/getbyid/:id', function (req, res) {
    Company.findById(req.params.id, function (err, company) {
        if (err) return res.status(500).send("There was a problem finding the company.");
        if (!company) return res.status(404).send("No company found.");
        res.status(200).send(company);
    });
});

// GETS A SINGLE COMPANY BY NAME FROM THE DATABASE
router.get('/getbyname/:name', function (req, res) {
    Company.find({name_company: req.params.name}, function (err, company) {
        if (err) return res.status(500).send("There was a problem finding the company.");
        if (!company.length) return res.status(404).send("No company found.");
        res.status(200).send(company);
    });
});

// DELETES A COMPANY FROM THE DATABASE
router.delete('/delete/:id', function (req, res) {
    Company.findByIdAndRemove(req.params.id, function (err, company) {
        if (err) return res.status(500).send("There was a problem deleting the company.");
        res.status(200).send("Company: "+ company.name_company +" was deleted.");
    });
});

// UPDATES A SINGLE COMPANY IN THE DATABASE
router.put('/update/:id', function (req, res) {
    Company.findByIdAndUpdate(req.params.id, req.body, {new: true}, function (err, company) {
        if (err) return res.status(500).send("There was a problem updating the company.");
        res.status(200).send(company);
    });
});

module.exports = router;