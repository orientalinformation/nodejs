var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');

router.use(bodyParser.urlencoded({ extended: true }));
router.use(bodyParser.json());

var GW = require('../models/GW');

// CREATES A NEW GW
router.post('/create', function (req, res) {
    GW.findById(req.body._id, function(err, gw) {
        if (err) return res.status(500).send(err);
        if (gw) return res.status(404).send('ID is already taken');

        var newGW            = new GW();          
        newGW._id            = req.body._id,
        newGW.name_gw        = req.body.name_gw,
        newGW.IP_public      = req.body.IP_public,
        newGW.MAC_add        = req.body.MAC_add,
        newGW.OS             = req.body.OS
    
        newGW.save(function(err) {
            if (err) return res.status(500).send("There was a problem adding the information to the database.");
            res.status(200).send(newGW);
        });
    });  
});

// RETURNS ALL THE GW IN THE DATABASE
router.get('/getall', function (req, res) {
    GW.find({}, function (err, gw) {
        if (err) return res.status(500).send("There was a problem finding the GW.");
        res.status(200).send(gw);
    });
});

// GETS A SINGLE GW BY ID FROM THE DATABASE
router.get('/getbyid/:id', function (req, res) {
    GW.findById(req.params.id, function (err, gw) {
        if (err) return res.status(500).send("There was a problem finding the GW.");
        if (!gw) return res.status(404).send("No GW found.");
        res.status(200).send(gw);
    });
});

// GETS A SINGLE GW BY NAME FROM THE DATABASE
router.get('/getbyname/:name', function (req, res) {
    GW.find({name_gw: req.params.name}, function (err, gw) {
        if (err) return res.status(500).send("There was a problem finding the gw.");
        if (!gw.length) return res.status(404).send("No gw found.");
        res.status(200).send(gw);
    });
});

// DELETES A GW FROM THE DATABASE
router.delete('/delete/:id', function (req, res) {
    GW.findByIdAndRemove(req.params.id, function (err, gw) {
        if (err) return res.status(500).send("There was a problem deleting the GW.");
        res.status(200).send("GW: "+ gw.name_gw +" was deleted.");
    });
});

// UPDATES A SINGLE GW IN THE DATABASE
router.put('/update/:id', function (req, res) {
    GW.findByIdAndUpdate(req.params.id, req.body, {new: true}, function (err, gw) {
        if (err) return res.status(500).send("There was a problem updating the GW.");
        res.status(200).send(gw);
    });
});

module.exports = router;