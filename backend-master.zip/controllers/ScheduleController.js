var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');
var fs = require("fs");
var request = require('request');

router.use(bodyParser.urlencoded({ extended: true }));
router.use(bodyParser.json());

var Schedule = require('../models/Schedule');

// CREATES A NEW SCHEDULE
router.post('/create', function (req, res) {
    Schedule.create({
        id_gw : req.body.id_gw,
        id_node : req.body.id_node,
        createtime : req.body.createtime,
        message : req.body.message
        }, 
        function (err, schedule) {
            if (err) return res.status(500).send("There was a problem adding the information to the database.");
            res.status(200).send(schedule);
        });
});

// RETURNS ALL THE SCHEDULE IN THE DATABASE
router.get('/getall', function (req, res) {
    Schedule.find({}, function (err, schedule) {
        if (err) return res.status(500).send("There was a problem finding the schedule.");
        res.status(200).send(schedule);
    });
});

// GETS A SINGLE SCHEDULE BY ID FROM THE DATABASE
router.get('/getbyid/:id', function (req, res) {
    Schedule.findById(req.params.id, function (err, schedule) {
        if (err) return res.status(500).send("There was a problem finding the schedule.");
        if (!schedule) return res.status(404).send("No schedule found.");
        res.status(200).send(schedule);
    });
});

// DELETES A SCHEDULE FROM THE DATABASE
router.delete('/delete/:id', function (req, res) {
    Schedule.findByIdAndRemove(req.params.id, function (err, schedule) {
        if (err) return res.status(500).send("There was a problem deleting the schedule.");
        res.status(200).send("Schedule was deleted.");
    });
});

// UPDATES A SINGLE SCHEDULE IN THE DATABASE
router.put('/update/:id', function (req, res) {
    Schedule.findByIdAndUpdate(req.params.id, req.body, {new: true}, function (err, schedule) {
        if (err) return res.status(500).send("There was a problem updating the schedule.");
        res.status(200).send(schedule);
    });
});


// var value = "03670110018806765ff2960a0003e8067104D2FB2E0000046801";

router.post('/createdata', function (req, res) {      
    var value = req.body.value;

    fs.readFile( "./" + "codec.json", 'utf8', function (err, data) {
        var pos_start = 0;
        var data = JSON.parse( data );
        var obj;
        var long_obj;
        var result;
        var arr = [];
        var data_length = data.length;

        while(value.length > 0){
            var pos = pos_start + 2;
            var code = value.substring(pos, pos + 2);
            
            obj = data.find(item => item._id === parseInt(code));

            long_obj = obj.long;
            pos = pos + 2;
            
            pos = pos + long_obj;
            result = value.substring(pos_start + 4, pos);

            if(obj._id == 67) {
                
                var jsonDataObj = {'data': result};

                request.post({
                    url:     'http://localhost:8888/schedule/temperature',
                    body:    jsonDataObj,
                    json: true,       
                }, function(error, response, body){
                    arr.push(body);       
                    if(arr.length == data_length){
                       
                        var jsonDataObj = {
                            'id_gw': "1",
                            'id_node': "1",
                            'message': arr
                        };

                        request.post({
                            url:     'http://localhost:8888/schedule/create',
                            body:    jsonDataObj,
                            json: true,       
                        });

                    }       
                });
            }
            
            if(obj._id == 68) {
                
                var jsonDataObj = {'data': result};

                request.post({
                    url:     'http://localhost:8888/schedule/humidity',
                    body:    jsonDataObj,
                    json: true,       
                }, function(error, response, body){
                    arr.push(body); 
                    if(arr.length == data_length){
                        
                        var jsonDataObj = {
                            'id_gw': "1",
                            'id_node': "1",
                            'message': arr
                        };

                        request.post({
                            url:     'http://localhost:8888/schedule/create',
                            body:    jsonDataObj,
                            json: true,       
                        });

                    }
                });
            }

            if(obj._id == 71) {
                
                var jsonDataObj = {'data': result};

                request.post({
                    url:     'http://localhost:8888/schedule/accelerometer',
                    body:    jsonDataObj,
                    json: true,
                }, function(error, response, body){
                    arr.push(body);   
                    if(arr.length == data_length){
                       
                        var jsonDataObj = {
                            'id_gw': "1",
                            'id_node': "1",
                            'message': arr
                        };

                        request.post({
                            url:     'http://localhost:8888/schedule/create',
                            body:    jsonDataObj,
                            json: true,       
                        });

                    }
                });
            }

            if(obj._id == 88) {
                
                var jsonDataObj = {'data': result};

                request.post({
                    url:     'http://localhost:8888/schedule/GPS',
                    body:    jsonDataObj,
                    json: true,
                }, function(error, response, body){
                    arr.push(body);    
                    if(arr.length == data_length){
                        
                        var jsonDataObj = {
                            'id_gw': "1",
                            'id_node': "1",
                            'message': arr
                        };

                        request.post({
                            url:     'http://localhost:8888/schedule/create',
                            body:    jsonDataObj,
                            json: true,       
                        });

                    }
                });
            }
         
            value = value.substring(pos);
                  
        }

        res.status(200).send();

    });  
});

router.post('/temperature', function (req, res) {
    var data = req.body.data;
   
    data = data.toString(16);
       
    data = parseInt(data, 16); 
                       
    data = data / 10; 
    
    var obj = {
        "name": "temperature",
        "value": data 
    };

    res.send(obj);
    
});

router.post('/humidity', function (req, res) {
    var data = req.body.data;
   
    data = data.toString(16);
       
    data = parseInt(data, 16); 
    
    var obj = {
        "name": "humidity",
        "value": data 
    };

    res.send(obj);
    
});

router.post('/accelerometer', function (req, res) {
    var data = req.body.data;

    var x = data.substring(0,4);
    x = x.toString(16);      
    x = parseInt(x, 16);                 
    x = x / 10;

    var y = data.substring(4,8);
    y = y.toString(16);      
    y = parseInt(y, 16);                 
    y = y / 10;

    var z = data.substring(8,12);
    z = z.toString(16);      
    z = parseInt(z, 16);                 
    z = z / 10;

    var obj = {
        "name": "accelerometer",
        "value": {
            "X":x,
            "Y":y,
            "Z":z
        }
    };

    res.send(obj);

});

router.post('/GPS', function (req, res) {
    var data = req.body.data;

    var latitude = data.substring(0,6);
    latitude = latitude.toString(16);      
    latitude = parseInt(latitude, 16);                 
    latitude = latitude / 10000;

    var longitude = data.substring(6,12);
    longitude = longitude.toString(16);      
    longitude = parseInt(longitude, 16);                 
    
    var altitude = data.substring(12,18);
    altitude = altitude.toString(16);      
    altitude = parseInt(altitude, 16);                 
    altitude = altitude / 100;

    var obj = {
        "name": "GPS",
        "value": {
            "latitude":latitude,
            "longitude":longitude,
            "altitude":altitude
        }
    };

    res.send(obj);

});

module.exports = router;