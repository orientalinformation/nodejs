var app = require('./app');
var request = require('request');
// var port = process.env.PORT || 3000;

app.get('/', function (req, res) {
  res.send('Hello DFM!');
});

var port = 8888;
var server = app.listen(port, function() {
  console.log('Express server listening on port ' + port);
});

var PORT = 1780;
var HOST = '192.168.30.26';

var dgram = require('dgram');
var server = dgram.createSocket('udp4');

server.on('listening', function () {
    var address = server.address();
    console.log('UDP Server listening on ' + address.address + ":" + address.port);
});

server.on('message', function (message, remote) {
   console.log(remote.address + ':' + remote.port +' - ' + message);

    message = JSON.parse(message);
    console.log(message);

    request.post({
        url:     'http://localhost:8888/lora/joinrequest',
        body:    message,
        json: true,       
    },function(error, response, body){
        console.log("send: " + body);
        console.log("------------------------------------");

        server.send(body,7777,'localhost',function(error){
            if(error){
              client.close();
            }else{
              console.log('Data sent !!!');
            }
          
          });
    });

});

server.bind(PORT, HOST);