var mongoose = require('mongoose');  

var GroupSchema = new mongoose.Schema({  
    _id: Number,
    id_company: String,
    group_name: String
},{ versionKey: false });

mongoose.model('group', GroupSchema, 'group');

module.exports = mongoose.model('group');