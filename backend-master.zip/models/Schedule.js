var mongoose = require('mongoose');  

var ScheduleSchema = new mongoose.Schema({  
    //_id: Number,
    id_gw: String,
    id_node: String,
    createtime: { 
        type: Date, 
        default: Date.now 
    },
    message: Object
},{ versionKey: false });

mongoose.model('schedule', ScheduleSchema, 'schedule');

module.exports = mongoose.model('schedule');