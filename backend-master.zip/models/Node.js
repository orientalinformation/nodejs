var mongoose = require('mongoose');  

var NodeSchema = new mongoose.Schema({  
    _id: Number,
    name_node: String,
    status: String,
    OS: String,
    dev_eui: String,
    app_eui: String,
    app_key: String,
    id_group: String,
    Manufacture: String,
    Profile: Object,
    Codec: String
},{ versionKey: false });

mongoose.model('node', NodeSchema, 'node');

module.exports = mongoose.model('node');