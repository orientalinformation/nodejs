var mongoose = require('mongoose');  

var UserSchema = new mongoose.Schema({  
    _id: Number,
    id_company: String,
    id_role: String,
    name_user: { 
        type: String, 
        required: true 
    },
    email: String,
    password:{ 
        type: String, 
        required: true 
    }
},{ versionKey: false });

mongoose.model('user', UserSchema, 'user');

module.exports = mongoose.model('user');