var mongoose = require('mongoose');  

var GWSchema = new mongoose.Schema({  
    _id: Number,
    name_gw: String,
    IP_public: String,
    MAC_add: String,
    OS: String
},{ versionKey: false });

mongoose.model('GW', GWSchema, 'GW');

module.exports = mongoose.model('GW');