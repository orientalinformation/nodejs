var mongoose = require('mongoose');  

var GWnodeSchema = new mongoose.Schema({  
    _id: Number,
    id_company: String,
    id_gw: String,
    id_node: String
},{ versionKey: false });

mongoose.model('GW-node', GWnodeSchema, 'GW-node');

module.exports = mongoose.model('GW-node');