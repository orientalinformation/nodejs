var mongoose = require('mongoose');  

var CompanySchema = new mongoose.Schema({  
    _id: Number,
    name_company: String,
    address: String,
    tax_number: String,
    phone: String
},{ versionKey: false });
mongoose.model('company', CompanySchema, 'company');

module.exports = mongoose.model('company');