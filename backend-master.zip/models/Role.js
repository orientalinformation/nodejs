var mongoose = require('mongoose');  

var RoleSchema = new mongoose.Schema({  
    _id: Number,
    role_name : String
},{ versionKey: false });

mongoose.model('role', RoleSchema, 'role');

module.exports = mongoose.model('role');