var express = require('express');
var app = express();
var db = require('./db');

app.use(function (req, res, next) {
    // Website you wish to allow to connect
    res.setHeader('Access-Control-Allow-Origin', '*');
    
    // Request methods you wish to allow
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
    
    // Request headers you wish to allow
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
    
    // Set to true if you need the website to include cookies in the requests sent
    // to the API (e.g. in case you use sessions)
    res.setHeader('Access-Control-Allow-Credentials', true);
    
    // Pass to next layer of middleware
    next();
});

var CompanyController = require('./controllers/CompanyController');
app.use('/company', CompanyController);

var UserController = require('./controllers/UserController');
app.use('/user', UserController);

var RoleController = require('./controllers/RoleController');
app.use('/role', RoleController);

var ScheduleController = require('./controllers/ScheduleController');
app.use('/schedule', ScheduleController);

var GroupController = require('./controllers/GroupController');
app.use('/group', GroupController);

var GWController = require('./controllers/GWController');
app.use('/gw', GWController);

var NodeController = require('./controllers/NodeController');
app.use('/node', NodeController);

var GWnodeController = require('./controllers/GWnodeController');
app.use('/gwnode', GWnodeController);

var LoraController = require('./controllers/LoraController');
app.use('/lora', LoraController);

var AlarmController = require('./controllers/AlarmController');
app.use('/alarm', AlarmController);

var ChartController = require('./controllers/ChartController');
app.use('/chart', ChartController);

module.exports = app;